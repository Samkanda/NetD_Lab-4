﻿'By: Navpreet Kanda
'Date: 2020-03-13
'Description: This represents the car class that stores certain properties regarding each car unit
Option Strict On
Public Class CarClass

#Region "Variable Declarations"
    Private Shared carCount As Integer = 0
    Public carIdentificationNumber As Integer = 0
    Public carMake As String = String.Empty
    Public carYear As Integer = 0
    Public carModel As String = String.Empty
    Public carPrice As Decimal = 0.0D
    Public carisNew As Boolean = False
#End Region

#Region "Constructors"
    'Default constructor: Increments the car count
    Friend Sub New()
        carCount += 1
        carIdentificationNumber = carCount
    End Sub

    'Paretrized constructor: sets all private varaibles based on arguements passed in
    Friend Sub New(makeValue As String, modelValue As String, yearValue As Integer,
    priceValue As Decimal, newValue As Boolean)

        Me.New()
        carMake = makeValue
        carModel = modelValue
        carYear = yearValue
        carPrice = priceValue
        carisNew = newValue

    End Sub
#End Region

#Region "Property Procedures"
    'Returns number of Car objects
    Public Shared ReadOnly Property Count() As Integer
        Get
            Return carCount
        End Get
    End Property

    Public ReadOnly Property ID() As Integer
        Get
            Return carIdentificationNumber
        End Get
    End Property

    Public Property Make() As String
        Get
            Return carMake
        End Get
        Set(value As String)
            carMake = value
        End Set
    End Property

    Public Property Model() As String
        Get
            Return carModel
        End Get
        Set(value As String)
            carModel = value
        End Set
    End Property

    Public Property Year() As Integer
        Get
            Return carYear
        End Get
        Set(value As Integer)
            carYear = value
        End Set
    End Property

    Public Property Price() As Decimal
        Get
            Return carPrice
        End Get
        Set(value As Decimal)
            carPrice = value
        End Set
    End Property

    Public Property isNew() As Boolean
        Get
            Return carisNew
        End Get
        Set(value As Boolean)
            carisNew = value
        End Set
    End Property
#End Region

#Region "Methods"
    Friend Function GetCarData() As String
        Return IIf(carisNew, "New ", "Used ").ToString & carYear & " " & carMake & " " & carModel & " for " & carPrice.ToString("c")
    End Function
#End Region
End Class
